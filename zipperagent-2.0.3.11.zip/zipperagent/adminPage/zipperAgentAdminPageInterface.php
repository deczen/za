<?php

interface zipperAgentAdminPageInterface {
	
	public function getPage();
	
	public function registerSettings();
	
}