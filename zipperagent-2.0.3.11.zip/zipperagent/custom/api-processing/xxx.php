<?php
if( ! defined('ABSPATH') )
		include "../../../../../wp-load.php";

echo "sname: $sname, type: $type, sourceid: $sourceid" . "<hr />";